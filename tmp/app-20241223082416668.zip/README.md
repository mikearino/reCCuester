# Ticket reCCuester :robot:

#### An app I built to help quickly swap out the ticket requester for an individual cc'd into a ticket.

<p align="center">
  <img src="assets/screen.png">
</p>

## Description

This is a Zendesk App built to help swap out the ticket requester for an individual cc'd into a ticket. Users can choose from a dropdown menu of CC'd individuals and also click on a checkbox to keep the requester of the ticket CC'd into the thread.

## Known Bugs

- None

## Technologies Used

- Zendesk
- ZCLI
- html
- css
- js

## Support and contact details

If there are any questions, bugs or concerns, please contact mikeylofgren@gmail.com

### License

_This software is licensed under the MIT license_
